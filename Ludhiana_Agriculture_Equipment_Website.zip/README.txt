# Shaktiman Spare Parts Distributor — Website

Files:
- index.html — complete responsive homepage
- styles.css — design and mobile responsive styling
- homepage-reference.png — uploaded design reference

Business details currently entered:
Name: Shaktiman Spare Parts Distributor
Address: Near Krishna Public Inter College, New Behsa Colony, Transport Nagar, Lucknow – 226009, Uttar Pradesh
Phone: +91 7889255001

Google visibility:
1. First create/claim and verify the Google Business Profile.
2. Add the exact real-world business address and pin.
3. Add this website URL after hosting it.
4. Keep business name, address and phone consistent across the website and Google Business Profile.

Important: putting an address in website code does NOT by itself create a Google Maps listing. Google Business Profile must be added/claimed and verified separately.

Google location link supplied by owner:
https://share.google/VySBAA29ruVEgvbqA
